import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api } from "../api";
import { InvestigationReport } from "../types";
import RiskScoreCard from "../components/RiskScoreCard";
import EvidenceCard from "../components/EvidenceCard";
import StatusBadge from "../components/StatusBadge";

type Tab =
  | "overview"
  | "company"
  | "people"
  | "relationships"
  | "evidences"
  | "sources"
  | "timeline"
  | "apis"
  | "report";

const TABS: { id: Tab; label: string }[] = [
  { id: "overview", label: "Visão geral" },
  { id: "company", label: "Empresa" },
  { id: "people", label: "Sócios" },
  { id: "relationships", label: "Relacionamentos" },
  { id: "evidences", label: "Evidências" },
  { id: "sources", label: "Fontes" },
  { id: "timeline", label: "Timeline" },
  { id: "apis", label: "APIs utilizadas" },
  { id: "report", label: "Relatório" }
];

export default function Investigation() {
  const { id } = useParams();
  const [report, setReport] = useState<InvestigationReport | null>(null);
  const [tab, setTab] = useState<Tab>("overview");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    api
      .getInvestigation(id)
      .then(setReport)
      .catch((e) => setError(e.message));
  }, [id]);

  if (error) return <p className="text-red-400">{error}</p>;
  if (!report) return <p className="text-muted">Carregando investigação...</p>;

  const { investigation, company, people, relationships, evidences, sources, riskFactors, timeline, apiUsage, limitations } =
    report;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-semibold">{company?.razao_social || investigation.cnpj}</h1>
          <p className="text-muted text-sm">{investigation.cnpj}</p>
        </div>
        <StatusBadge status={investigation.status} />
      </div>

      {investigation.status === "error" && (
        <div className="bg-red-400/10 border border-red-400/30 text-red-300 rounded-lg p-4 mb-6 text-sm">
          Não foi possível obter dados cadastrais deste CNPJ nas fontes disponíveis (BrasilAPI / ReceitaWS). Isso
          pode ocorrer por indisponibilidade temporária das APIs, CNPJ inexistente, ou bloqueio de rede no ambiente
          atual.
        </div>
      )}

      <div className="flex gap-2 border-b border-border mb-6 overflow-x-auto">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`px-3 py-2 text-sm whitespace-nowrap border-b-2 transition ${
              tab === t.id ? "border-accent text-accent" : "border-transparent text-muted hover:text-text"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "overview" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <RiskScoreCard score={investigation.risk_score} band={investigation.risk_band} factors={riskFactors} />
          </div>
          <div className="md:col-span-2 space-y-4">
            <div className="bg-panel border border-border rounded-xl p-5">
              <h3 className="text-sm uppercase tracking-wide text-muted mb-3">Resumo</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <Stat label="Sócios encontrados" value={people.length} />
                <Stat label="Evidências coletadas" value={evidences.length} />
                <Stat label="Relacionamentos mapeados" value={relationships.length} />
                <Stat label="Fontes consultadas" value={sources.length} />
              </div>
            </div>
            <div className="bg-panel border border-border rounded-xl p-5">
              <h3 className="text-sm uppercase tracking-wide text-muted mb-3">Limitações da investigação</h3>
              <ul className="text-sm text-muted list-disc list-inside space-y-1">
                {limitations.map((l, i) => (
                  <li key={i}>{l}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {tab === "company" && company && (
        <div className="bg-panel border border-border rounded-xl p-6 grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <Field label="Razão social" value={company.razao_social} />
          <Field label="Nome fantasia" value={company.nome_fantasia} />
          <Field label="Situação cadastral" value={company.situacao_cadastral} />
          <Field label="Data de abertura" value={company.data_abertura} />
          <Field label="CNAE" value={company.cnae} />
          <Field label="Endereço" value={company.endereco} />
          <Field label="Município/UF" value={`${company.municipio}/${company.estado}`} />
          <Field label="Capital social" value={company.capital_social} />
          <Field label="Natureza jurídica" value={company.natureza_juridica} />
          <Field label="Porte" value={company.porte} />
          <Field label="Fonte" value={company.source_name} />
          <Field label="Consultado em" value={new Date(company.consulted_at).toLocaleString("pt-BR")} />
        </div>
      )}
      {tab === "company" && !company && <p className="text-muted">Nenhum dado cadastral disponível.</p>}

      {tab === "people" && (
        <div className="space-y-3">
          {people.length === 0 && <p className="text-muted">Nenhum sócio encontrado nas fontes consultadas.</p>}
          {people.map((p) => (
            <div key={p.id} className="bg-panel border border-border rounded-lg p-4 flex items-center justify-between">
              <div>
                <p className="font-medium">{p.name}</p>
                <p className="text-xs text-muted">{p.role}</p>
              </div>
              <div className="flex gap-4 text-xs text-muted text-right">
                <span>Empresas relacionadas: {p.related_companies_count}</span>
                <span>Documentos encontrados: {p.documents_count}</span>
                <span>Ocorrências: {p.occurrences_count}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === "relationships" && (
        <div className="space-y-2">
          {relationships.length === 0 && <p className="text-muted">Nenhum relacionamento mapeado.</p>}
          {relationships.map((r) => (
            <div key={r.id} className="bg-panel border border-border rounded-lg p-3 text-sm flex items-center gap-2">
              <span className="font-medium">{r.from_entity}</span>
              <span className="text-accent text-xs px-2 py-0.5 rounded bg-accentSoft/40">{r.relationship_type}</span>
              <span className="font-medium">{r.to_entity}</span>
            </div>
          ))}
        </div>
      )}

      {tab === "evidences" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {evidences.length === 0 && <p className="text-muted">Nenhuma evidência coletada.</p>}
          {evidences.map((e) => (
            <EvidenceCard key={e.id} evidence={e} />
          ))}
        </div>
      )}

      {tab === "sources" && (
        <div className="space-y-2">
          {sources.map((s) => (
            <div key={s.id} className="bg-panel border border-border rounded-lg p-3 flex items-center justify-between">
              <span className="text-sm">{s.name}</span>
              <div className="flex items-center gap-2">
                {!!s.is_mock && (
                  <span className="text-[10px] px-2 py-0.5 rounded bg-amber-400/10 text-amber-400 border border-amber-400/30">
                    MOCK
                  </span>
                )}
                <StatusBadge status={s.status} />
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === "timeline" && (
        <div className="space-y-4 border-l border-border pl-4">
          {timeline.length === 0 && <p className="text-muted">Nenhum evento registrado.</p>}
          {timeline.map((t) => (
            <div key={t.id} className="relative">
              <div className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-accent" />
              <p className="text-xs text-muted">{new Date(t.date).toLocaleDateString("pt-BR")}</p>
              <p className="font-medium text-sm">{t.title}</p>
              <p className="text-sm text-muted">{t.description}</p>
            </div>
          ))}
        </div>
      )}

      {tab === "apis" && (
        <div className="space-y-2">
          {apiUsage.map((u: any, i: number) => (
            <div key={i} className="bg-panel border border-border rounded-lg p-3 flex items-center justify-between text-sm">
              <span>{u.connector_id}</span>
              <span className="text-muted">
                {u.total} consulta(s) · tempo médio {Math.round(u.avg_ms || 0)}ms
              </span>
            </div>
          ))}
        </div>
      )}

      {tab === "report" && (
        <div className="bg-panel border border-border rounded-xl p-6">
          <p className="text-sm text-muted mb-4">
            O relatório completo (JSON estruturado) pode ser obtido via API:
          </p>
          <code className="block bg-panel2 rounded p-3 text-xs text-accent break-all">
            GET /api/investigations/{investigation.id}/report
          </code>
          <p className="text-xs text-muted mt-4">
            Este JSON reúne empresa, sócios, relacionamentos, evidências, fontes, índice de risco, timeline e
            limitações — pronto para exportação ou geração de PDF em uma etapa futura.
          </p>
        </div>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <p className="text-2xl font-semibold">{value}</p>
      <p className="text-xs text-muted">{label}</p>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string | null | undefined }) {
  return (
    <div>
      <p className="text-xs text-muted uppercase tracking-wide">{label}</p>
      <p className="text-text/90">{value || "—"}</p>
    </div>
  );
}
