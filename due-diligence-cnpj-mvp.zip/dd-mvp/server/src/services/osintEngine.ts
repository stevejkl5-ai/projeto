import { newsSearchConnector } from "../connectors/newsSearch";
import { ConnectorResult } from "../types";

/**
 * OsintEngine: gera combinações de busca para uma pessoa ou empresa e executa
 * o connector de notícias/busca disponível para cada combinação.
 * IMPORTANTE: resultados são apresentados como evidência para análise humana,
 * nunca como prova automática de irregularidade.
 */
export class OsintEngine {
  buildQueries(entityName: string, entityType: "person" | "company"): string[] {
    if (entityType === "person") {
      return [
        `"${entityName}"`,
        `"${entityName}" empresa`,
        `"${entityName}" CNPJ`,
        `"${entityName}" processo`,
        `"${entityName}" contrato`,
        `"${entityName}" notícia`
      ];
    }
    return [
      `"${entityName}" processo`,
      `"${entityName}" reclamação`,
      `"${entityName}" fraude`,
      `"${entityName}" investigação`
    ];
  }

  async run(entityName: string, entityType: "person" | "company"): Promise<{ query: string; result: ConnectorResult }[]> {
    const queries = this.buildQueries(entityName, entityType);
    const results: { query: string; result: ConnectorResult }[] = [];
    for (const q of queries) {
      const result = await newsSearchConnector.searchPerson!(q);
      results.push({ query: q, result });
    }
    return results;
  }
}

export const osintEngine = new OsintEngine();
